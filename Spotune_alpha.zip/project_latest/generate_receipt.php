<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Receipt</title>
    <link rel="stylesheet" type="text/css" href="css/receipt.css">
</head>
<body>
 <div class="h"><h1>Spo<span>Tune++</span></h1></div>
	<?php  

        $email = $_SESSION['email'];
        
        ini_set( 'display_errors', 1);
        error_reporting( E_ALL );
        
        $to = "$email";
        $from = "spotune1@gmail.com";
        $subject = "Payment Invoice";

        $message = "Hi, ".$_POST["nameOnCard"].",
        Thank you for your Spotune++ subscription. Here is your information:
        Full Name: ".$_POST["nameOnCard"]."
        Email: ".$_POST["cardNumber"]."
        Subscription: ".$_SESSION["sub"]."

        Please enjoy your music!";
        
        
        $headers = "Spotune++ Subscription" ;
        
        if (mail($to, $subject, $message, $headers)) {
           echo "SUCCESS";
        } else {
           echo "ERROR";
        }

        echo '<br><br>Payment Successful! An email has been sent to '. $email.'.';


        echo "<br>";
        echo "Full Name :".$_POST["nameOnCard"];
        echo "<br>";
        echo "CARD NO :".$_POST["cardNumber"];
        echo "<br>";
        echo "EMAIL :".$email;
        echo "<br>";
        echo "SUBSCRIPTION : ".$_SESSION['sub'];
        echo "<br>";

        $_SESSION['nameOnCard'] = $_POST['nameOnCard'];
        $_SESSION['cardNumber'] = $_POST['cardNumber'];

        include_once('config.php');

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $date = date("Y/m/d");
        $sub = $_SESSION['sub'];
        $cardNumber = $_SESSION['cardNumber'];

        $sql = "INSERT INTO orders (email, date, subs_type, card_number) VALUES ('$email', '$date', '$sub', '$cardNumber')";

        if (mysqli_query($conn, $sql)) {

            echo "Record updated successfully <br>";
            $update = "UPDATE users SET subs_status = '1' WHERE subs_status = '0'";
            if (mysqli_query($conn, $update)){
                echo "Successfully update subscription status for ".$email."<br>";
            }
        } else {
            echo "Error updating record: " . mysqli_error($conn);
            echo "<br>";
        }
    
    ?>

    <button><a href="menu.php" style="text-decoration:none; color:black;">Go to Menu</a></button>
    <button><a href="receipt_generator.php" style="text-decoration:none; color:black;">Generate Receipt</a></button>
</body>
</html>