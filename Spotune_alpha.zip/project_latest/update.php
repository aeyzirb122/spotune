<!DOCTYPE html>
<html> 
<head>
	
</head>

<body>

<form action="upload.php" method="POST" enctype="multipart/form-data">
<input type="file" name="audioFile"/>
<input type="submit" value="Upload Audio" name="save_audio"/>
</form>

</body>
</html>