    <!DOCTYPE html>
    <html>
    <head>
    <title>Table with database</title>
    </head>
    <body>
    <table border="1" cellpadding="1" cellspacing="1">
    <tr>
    <th>User ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Password</th>
    <th>Gender</th>
    <th>State</th>
    <th>Delete</th>
    </tr>


     <?php
    $conn = mysqli_connect("localhost", "id11848911_mydata", "mydata", "id11848911_spotune");
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    echo "<tr><td>" . $row["user_id"]. "</td><td>" . $row["first_name"] . ' ' . $row["last_name"] . "</td><td>".$row["email"] . "</td><td>" . $row["password"]. "</td><td>".$row["gender"]."</td><td>".$row["state"]."</td> <td><a href=delete.php?id=".$row["user_id"] .">Delete</a></td></tr>";
    }
    echo "</table>";
    } else { echo "0 results"; }
    $conn->close();
    ?>

    </table>
    </body>
    </html>