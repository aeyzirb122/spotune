<html>
<body>

<?php
$servername = "localhost";
$username = "username";
$password = "password";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else
{
echo "Connected successfully";
}

echo "<p> YOUR INFORMATION: </p>";

echo "Email :".$_POST["email"];
echo "<br>";
echo "State :".$_POST["state"];
echo "<br>";
echo "Gender :".$_POST["gender"];
echo "<br>";
echo "Mobile Number :".$_POST["phonenumber"];
echo "<br>";
echo "New Password :".$_POST["newpass"];
echo "<br>";
echo "Old Password :".$_POST["oldpass"];
echo "<br>";
?> 
</body>
</html> 