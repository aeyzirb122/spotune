
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
        <title>Subscription</title>
        <link rel="stylesheet" type="text/css" href="css/subcribe.css">
        <link href="https://fonts.googleapis.com/css?family=Cinzel" rel="stylesheet">

    <style>
        a{
            text-decoration: none;
            color: black;
        }
    </style>

</head>
 <div class="h"><h1>Spo<span>Tune++</span></h1></div>
 <body>
  <div class="bgimg">
   <div class="centerdiv">
    <img src="https://cdn1.iconfinder.com/data/icons/flat-business-icons/128/user-128.png" id="profilepic">


    

    <p>Subscription:</p>
    <form action="payment_transaction.php" method="POST">
        <input type="radio" name="sub" value="1 Month for $15." checked="checked">1 month<br>
        <input type="radio" name="sub" value="3 Month for $40.">3 month<br>
        <input type="radio" name="sub" value="1 Year for $150.">1 year<br>
        <input type="submit" name="submit">
    </form>
    </div>
   </div>
  </div>
  
 </body>
</html>
