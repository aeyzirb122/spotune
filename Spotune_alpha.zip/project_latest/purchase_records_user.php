<?php 

        session_start();
        include_once('config.php');
        $email = $_SESSION['email'];

        $sql = "SELECT * FROM orders WHERE email = '$email' ";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) == 1) {
          echo "This is your purchase records.<br>";

          while ($row = mysqli_fetch_assoc($result)) {
            echo $row['email']."     |     ".$row['date']."      |      ".$row['subs_type']."      |      ".$row['card_number'];
          }
        } else {
          echo "Error.".mysqli_error($conn);
        }

     ?>