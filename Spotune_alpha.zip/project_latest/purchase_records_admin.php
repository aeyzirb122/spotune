<?php 

       
        include_once('config.php');
        

        $sql = "SELECT * FROM orders";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result)) {
          echo "User purchase records.<br>";

          while ($row = mysqli_fetch_assoc($result)) {
            echo $row['email']."     |     ".$row['date']."      |      ".$row['subs_type']."      |      ".$row['card_number']. "<br>";
          }
        } else {
          echo "Error.".mysqli_error($conn);
        }

     ?>