<?php
	$conn = mysqli_connect("localhost", "root", "", "spotune");

    $sql = "DELETE FROM users WHERE user_id='$_GET[id]'";

	if (mysqli_query($conn, $sql))
	{
		echo "success";
		header("refresh:5; url=edit_list.php");	
	}
	else
	{
		echo "Not Deleted";
	}

?>