<?php 
  session_start();
 ?>

<!DOCTYPE html>
<head>

    <meta name="description" content="Music Player" />
    <link rel="stylesheet" href="css/main menu 2.css">
    <link href='https://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
    <title>Music Player</title>
    <meta charset=utf-8>

    <style>
      div.a {
      text-align: center;
      }
   </style>

</head>

<body>
   <div class="h"><h1>Spo<span>Tune++</span></h1></div>
  <div class="a">
  <h1>MUSICA FUTURE SYSTEM</h1>
  </div>

  <div class="tabbed">

    <input type="radio" name="tabs" id="tab-nav-1" checked>
    <label for="tab-nav-1">MAIN MENU</label>

    <input type="radio" name="tabs" id="tab-nav-2">
    <label for="tab-nav-2">SONG PLAYER</label>

    <input type="radio" name="tabs" id="tab-nav-3">
    <label for="tab-nav-3">PURCHASE RECORD</label>

    <div class="tabs">

      <div>
      	<h2>WELCOME</h2>
      	      <p>Welcome to Music Player where all the music are all branded!</p>
      	<h2>NEWLY UPDATE!</h2>
      	      <a href="https://www.youtube.com/505888f1-2b27-49ac-b6fc-d157e9dfe0a3"><img src="https://i.ytimg.com/vi/J2YRKAx6H7g/maxresdefault.jpg" alt="" width="100" height="100"></a>
              <img src="https://images.genius.com/8379aac7565d972098de4a7264ae1357.1000x1000x1.jpg" alt="" width="100" height="100">
              <img src="https://i1.sndcdn.com/artworks-000569028494-3ir13c-t500x500.jpg" alt="" width="100" height="100">
              <img src="https://i.ytimg.com/vi/SlPhMPnQ58k/maxresdefault.jpg" alt="" width="100" height="100">
              <img src="https://i.ytimg.com/vi/oluOhZQlhqY/maxresdefault.jpg" alt="" width="100" height="100">
              <img src="https://i.scdn.co/image/1865924edfe0a2bfe364e011a175715fe85d28b1" alt="" width="100" height="100">
              <img src="https://images.genius.com/6740136b094d0fe6c00ce14d4287a99e.1000x1000x1.jpg" alt="" width="100" height="100">
              <img src="https://www.billboard.com/files/styles/article_main_image/public/media/billie-eilish-bad-guy-vid-02-2019-billboard-1548.jpg" alt="" width="100" height="100">
              <img src="https://i.ytimg.com/vi/M84fFXooS5w/maxresdefault.jpg" alt="" width="100" height="100">
              <img src="https://upload.wikimedia.org/wikipedia/en/8/87/Jonas_Brothers_-_Sucker.png" alt="" width="100" height="100">
              <img src="https://i.ytimg.com/vi/r7qovpFAGrQ/maxresdefault.jpg" alt="" width="100" height="100">
              <img src="https://i.ytimg.com/vi/ZAfAud_M_mg/maxresdefault.jpg" alt="" width="100" height="100">
              <img src="https://i.ytimg.com/vi/FM7MFYoylVs/maxresdefault.jpg" alt="" width="100" height="100">
              <img src="https://www.rollingstone.com/wp-content/uploads/2018/06/sam-smith-too-good-at-goodbyes-60615456-7b05-4ded-b1fb-4950c92e8564.jpg" alt="" width="100" height="100">
              <img src="https://themighty.com/wp-content/uploads/2019/05/Screenshot-2019-05-20-15.34.46-1-1280x640.png" alt="" width="100" height="100">
              <img src="https://images.genius.com/bdb01bd972ae95534994ea013e7a3e2e.1000x1000x1.jpg" alt="" width="100" height="100">
              <img src="https://i.ytimg.com/vi/dhYOPzcsbGM/maxresdefault.jpg" alt="" width="100" height="100">
              <img src="https://upload.wikimedia.org/wikipedia/en/thumb/b/b2/Ariana_Grande_Thank_U_Next.png/220px-Ariana_Grande_Thank_U_Next.png" alt="" width="100" height="100">
      </div>


      <div>
      	<h2>ON PLAY SONG</h2>
      	      <audio src="" controls id="audioPlayer">
        Sorry, your browser doesn't support html5!
    </audio>
    <ul id="playlist">
      <p>List of Song:</p>
        <li class="current-song"><a href="uploads/Lil Nas X Old Town Road (ft. Billy Ray Cyrus) [Bass Boosted].mp3">Old Town Road</a></li>
        <li><a href="uploads/Ariana Grande - thank u, next (lyric video).mp3">Thank U Next</a></li>
        <li><a href="uploads/DJ Snake A Different Way (Lyrics).mp3">A Different Way</a></li>
         <li><a href="uploads/Khalid, Halsey - Eastside (Lyrics).mp3">Eastside</a></li>
         <li><a href="uploads/Khalid Saturday Nights (Lyrics).mp3">Saturday Nights</a></li>
         <li><a href="uploads/Khalid - Better (Official Video).mp3">Better</a></li>
         <li><a href="uploads/Post Malone - Goodbyes (Lyrics) ft. Young Thug.mp3">Goodbyes</a></li>
         <li><a href="uploads/Ali Gatie - It's You (Official Lyrics Video).mp3">Its You</a></li>
    </ul>

    <script src="https://code.jquery.com/jquery-2.2.0.js"></script>

    <script src="audioPlayer.js"></script>
    <script>
        
            audioPlayer();
            function audioPlayer(){
            var currentSong = 0;
            $("#audioPlayer")[0].src = $("#playlist li a")[0];
            $("#audioPlayer")[0].play();
            $("#playlist li a").click(function(e){
               e.preventDefault(); 
               $("#audioPlayer")[0].src = this;
               $("#audioPlayer")[0].play();
               $("#playlist li").removeClass("current-song");
                currentSong = $(this).parent().index();
                $(this).parent().addClass("current-song");
            });
            
            $("#audioPlayer")[0].addEventListener("ended", function(){
               currentSong++;
                if(currentSong == $("#playlist li a").length)
                    currentSong = 0;
                $("#playlist li").removeClass("current-song");
                $("#playlist li:eq("+currentSong+")").addClass("current-song");
                $("#audioPlayer")[0].src = $("#playlist li a")[currentSong].href;
                $("#audioPlayer")[0].play();
            });
        }

    </script>

      </div>

      <div>
      	<h2>PURCHASE RECORD</h2>

       <?php 

        include_once('config.php');

        $email = $_SESSION['email'];

        $sql = "SELECT * FROM orders WHERE email = '$email' ";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) == 1) {
          echo "This is your purchase records.<br>";

          while ($row = mysqli_fetch_assoc($result)) {
            echo $row['email']."     |     ".$row['date']."      |      ".$row['subs_type']."      |      ".$row['card_number'];
          }
        } else {
          echo "Error.".mysqli_error($conn);
        }

    
        ?>
      	      
   </div>
     
    </div>

    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.6/prefixfree.min.js"></script>

</body>
</html>
