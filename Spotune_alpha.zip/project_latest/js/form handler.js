<script> 
function FORM_HANDLER()                                    
{ 

    var subsrciption = document.forms["RegForm"]["Subsrciption"];


    if (subsrciption.value == 1)
    {
        alert("You not subscribe yet!");
        subsrciption.focus();
        return subscrcibe;
    }
   
    return true; 
}
</script> 
