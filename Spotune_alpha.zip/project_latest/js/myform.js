function validate(){
	var fname = document.forms["myForm"]["first"];
	var lname = document.forms["myForm"]["last"];
	var pw = document.forms["myForm"]["password"];
	var rpw = document.forms["myForm"]["confirmPass"];
	var gndr = document.forms["myForm"]["gender"];
	var agr = document.forms["myForm"]["check"];
	var letters = /^[A-Za-z]+$/;
	var pass= /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?!.*\s).{5,5}.\S*$/;

	if( fname.value == "" ){
		alert( "Please fill in your first name!" );
		fname.focus() ;
		return false;
	}
	if (fname.value.match(letters)){}else {
		alert('Your first name should in alphabet characters only');
		return false;
	}

	if( lname.value == "" ){
		alert( "Please fill in your last name!" );
		lname.focus() ;
		return false;
	}
	if (lname.value.match(letters)){}
	else {
		alert('Your last name should in alphabet characters only');
		return false;
	}

	if( document.myForm.email.value == "" ){
		alert( "Please fill in your email address!" );
		document.myForm.email.focus() ;
		return false;
	}

	if( pw.value == "" ){
		alert( "Please enter your password!" );
		pw.focus() ;
		return false;
	}
	if(pw.value.match(pass)){}
		else {
			alert('Your password must not be exceed 6 digit. You need to have at least ONE uppercase, ONE lowercase, ONE digit, ONE special characters and NO SPACES')
			return false;
		}

	if( rpw.value == "" ){
		alert( "Please confirm your password!" );
		rpw.focus() ;
		return false;
	}
	if (rpw.value.match(pw.value)){}
		else {
			alert('Your password is not same');
			return false;
		}

	if ((gndr[0].checked==false)&&(gndr[1].checked==false)) {
		alert("Please choose your gender");
		return false;
	}

    if (!agr.checked) {
		alert("Please agree on the Terms and Conditions!");
		return false;
	}

	alert("Good Job! You have done your registration.You can go back to main page.");
	return true;
}
document.getElementByName("clear").onclick = function() {reset()};
function reset() {
	alert("The form have been cleared!")
}