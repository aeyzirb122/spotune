function transaction() {

    var nameOnCard = document.forms["payTransaction"]["nameOnCard"]
    var cardNumber = document.forms["payTransaction"]["cardNumber"]
    var month = document.forms["payTransaction"]["month"]
    var year = document.forms["payTransaction"]["year"]
    var cvv = document.forms["payTransaction"]["cvv"]
    var email= document.forms["payTransaction"]["email"]

    //for validation, using regex expression
    var numOnly = /^[0-9]*$/
    var lettersOnly = /^[a-zA-Z\s]*$/
    var emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/

    if (nameOnCard.value == ""){
        alert("Please fill your name!");
        nameOnCard.focus();
        return false;
    }

    if (nameOnCard.value.match(lettersOnly)){

    } else{
        alert("Name must be alphabets only!");
        nameOnCard.focus();
        return false;
    }

    if (cardNumber.value == ""){
        alert("Please fill in your card number!");
        cardNumber.focus();
        return false;
    }

    if (cardNumber.value.match(numOnly)){

    } else{
        alert("Card number only accepts numbers only!");
        cardNumber.focus();
        return false;
    }

    if (month.value == "none"){
        alert("Please select month!");
        month.focus();
        return false;
    }

    if (year.value == "none"){
        alert("Please select year!");
        year.focus();
        return false;
    }

    if (cvv.value == ""){
        alert("Please enter your CVV!");
        cvv.focus();
        return false;
    }

    if (cvv.value.match(numOnly)){

    } else{
        alert("CVV must be numbers only!");
        cvv.focus();
        return false;
    }

    if (email.value == ""){
        alert("Please enter your email address!");
        email.focus();
        return false;
    }

    if (email.value.match(emailFormat)){

    } else{
        alert("Invalid email format!");
        email.focus();
        return false;
    }

    //all true, return true
    alert("You have pay. Please proceed.");
    return true;

    
}


function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}