<?php

session_start();
include_once('config.php');

if(isset($_POST['email']))
{
	$email=$_POST['email'];
	$password=$_POST['password'];

	$sql = "SELECT * FROM users where email='".$email."' AND password='".$password."' limit 1";

	$result = mysqli_query($conn, $sql);

	if(mysqli_num_rows($result) == 1)
	{
		//echo "You have sucessfully logged in";

		$_SESSION['email'] = $email;

		if($email=='admin@admin.com'){
			header("Location: admin.html");
			}
			else {
				while ($row = mysqli_fetch_assoc($result)) {
					if ($row['subs_status'] == 1){
						header("Location: personal.html");
					} else{
						header("Location: subscription.php");
					}
				}
				exit();
			}
				
			}
	else
	{
		echo "You have entered incorrect password";
		exit();
	}
}


?>
