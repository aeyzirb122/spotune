<?php 
	session_start();
	include_once('config.php');

	$first_name = $_POST['first'];
	$last_name = $_POST['last'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$gender = $_POST['gender'];
	$state = $_POST['state'];

	$sql = "INSERT INTO users (first_name, last_name, email, password, subs_status, gender, state) VALUES ('$first_name','$last_name','$email','$password','0','$gender','$state')";

	if (mysqli_query($conn, $sql)) {
		header("Location: login.html");
	} else {
		echo "Error updating record: " . mysqli_error($conn);
           echo "<br>";
	}



 ?>