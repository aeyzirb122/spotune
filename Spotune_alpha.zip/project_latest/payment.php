<!DOCTYPE html>
<head>
   <title>Payment secured</title>
</head>

<body>
    <?php

    <h1>Confirmation of your payment</h1>
     
     echo "<br>";
     echo NAME :$_POST["nameOnCard"];
     echo "<br>";
     echo CARD NO :$_POST["cardNumber"];
     echo "<br>";
     echo MONTH EXPIRY :$_POST["month"];
     echo "<br>";
     echo YEAR EXPIRY :$_POST["year"];
     echo "<br>";
     echo CVV :$_POST["cvv"];
     echo "<br>";
     echo EMAIL :$_POST["email"];
     echo "<br>";
?>
     
</body>

</html>