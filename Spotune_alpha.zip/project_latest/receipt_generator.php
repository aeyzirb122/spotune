<?php
	
	session_start();

	require('FPDF/fpdf.php');

	$pdf = new FPDF('P','mm','A4');
	$pdf->AddPage();
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(25, 5, 'Date', 0, 0);
	$pdf->Cell(52, 5, ': '.date("Y/m/d-l"), 0, 1);
	$pdf->Cell(55, 5, 'Status', 0, 0);
	$pdf->Cell(58, 5, ': Complete', 0, 1);
	$pdf->Ln(1);
	$pdf->Cell(25, 5, 'Spotune Receipt', 0, 0);
	$pdf->Line(10, 30, 200, 30);
	$pdf->Ln(10);
	$pdf->Cell(55, 5, 'Product Name', 0, 0);
	$pdf->Cell(58, 5, ': '.$_SESSION['sub'], 0, 1);
	$pdf->Cell(55, 5, 'Tax Amount', 0, 0);
	$pdf->Cell(58, 5, ': $0', 0, 1);
	$pdf->Ln(2);
	$pdf->Cell(55, 5, 'This is your purchase receipt. Please keep is for your future references.', 0, 0);
	$pdf->Line(10, 60, 200, 60);
	$pdf->Ln(6);
	$pdf->Cell(55, 5, 'Paid by', 0, 0);
	$pdf->Cell(58, 5, ': '.$_SESSION['nameOnCard'], 0, 1);
	$pdf->Cell(55, 5, 'Customer email', 0, 0);
	$pdf->Cell(58, 5, ': '.$_SESSION['email'], 0, 1);
	$pdf->Ln(5);
	$pdf->Line(160, 75, 200, 75);
	$pdf->Ln(5);
	$pdf->Cell(140, 5, '', 0, 0);
	$pdf->Cell(50, 5, 'This receipt is auto generated.', 0, 1, 'C');

	$pdf->Output();
?>
