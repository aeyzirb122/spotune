<!DOCTYPE html>
<head>
         <title>The user information</title>
</head>


<body>


   
   <h2>User Subscribe Information</h2><br>

   <?php

     

     if (isset($_POST['submit'])) 
     {
      $firstName = $_POST['first'];
      echo "First Name: ".$firstName ."<br>";

        $lastName = $_POST['last'];
      echo "Last Name: ".$lastName ."<br>";

      $email = $_POST['email'];
      echo "Email: ".$email ."<br>";

      $password = $_POST['password'];
      echo "Password: ".$password ."<br>";

      $gender = $_POST['gender'];
      echo "Gender: ".$gender ."<br>";

      $state = $_POST['state'];
      echo "State: ".$state ."<br>";

 
     }


  

   echo "<h2>Your Subsrciption:</h2>";
    
    echo "<br>";
    echo "Latest subscribe :".$_POST["sub"];
    echo "<br>";
    
  ?>
   
</body>

</html>