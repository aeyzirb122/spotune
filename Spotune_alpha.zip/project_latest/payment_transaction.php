<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <script src="js/transaction_up.js" type="text/javascript"></script>
  <title>Payment Transaction</title>
  <link rel="stylesheet" type="text/css" href="css/payment.css">
</head>
<body>
   <div class="h"><h1>Spo<span>Tune++</span></h1></div>

  <h1>Payment Transaction</h1>
  <div>
    <?php
      $sub_package = $_POST['sub'];
      $_SESSION['sub'] = $sub_package;

      echo 'Pay Spotune for ' . $sub_package;
    ?>
  </div>

  <h3>Credit Card Payment</h3>

  <form name="payTransaction" method="post" action="generate_receipt.php" onsubmit="return transaction()">
  
    <table>
      <tr>
        <td>Name on Card: </td>
        <td><input type="text" name="nameOnCard" placeholder="John Doe"></td>
      </tr>
      <tr>
        <td>Credit card number: </td>
        <td><input type="text" name="cardNumber" maxlength="16" placeholder="0001 5566 7728 7728" maxlength="16"></td>
      </tr>
      <tr>
        <td>Expiry Date: </td>
        <td>
          <select name="month">
            <option value="none" selected>Month</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
          </select>
        </td>
        <td>
          <select name="year">
            <option value="none" selected>Year</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>CVV: </td>
        <td><input type="text" name="cvv" placeholder="421" maxlength="3"></td>
      </tr> 
    </table>
      
    <input type="submit">
  </form>

  
</body>
</html>