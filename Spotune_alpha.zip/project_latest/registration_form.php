<!DOCTYPE html>
<html>
<head>
	<title>Registeration Form</title>
	<link rel="stylesheet" type="text/css" href="css/register.css">
</head>

<body>
	<form action="register.php" method="post" onsubmit="return(validate());">
		<table cellspacing="2" cellpadding="2" border="1" align="center">
			<td align="left" colspan="2"> Personal Information</td>
		<tr>
			<td align="right">First Name</td>
			<td><input type="text" name="first" /></td>
		</tr>
		<tr>
			<td align="right">Last Name</td>
			<td><input type="text" name="last" /></td>
		</tr>
		<tr>
			<td align="right">Email</td>
			<td><input type="email" name="email" /></td>
		</tr>
		<tr>
			<td align="right">Password</td>
			<td><input type="password" name="password" /></td>
		</tr>
		<tr>
			<td align="right">Confirm Password</td>
			<td><input type="password" name="confirmPass" /></td>
		</tr>
		<tr>
			<td align="right">Gender</td>
			<td>
				<input type="radio" name="gender" value="Male" >Male
				<input type="radio" name="gender" value="Female" >Female
			</td>
		</tr>
		<tr>
			<td align="right">State</td>
			<td>
				<input type="hidden" />
				<select name="state"> 
  					<option value="Sabah">Sabah</option>
  					<option value="Sarawak">Sarawak</option>
 					<option value="Pahang">Pahang</option>
 					<option value="Johor">Johor</option>
 					<option value="Kelantan">Kelantan</option>
 					<option value="Melaka">Melaka</option>
 					<option value="Perlis">Perlis</option>
 					<option value="N.Sembilan">N.Sembilan</option>
 					<option value="Pulau Pinang">Pulau Pinang</option>
 					<option value="Terengganu">Terengganu</option>
 					<option value="Kedah">Kedah</option>
 					<option value="Perak">Perak</option>
				</select>
			</td>
		</table><br>
			<textarea rows="5" cols="46"> Terms and Condition</textarea><br>
			<input type="checkbox" name="check" value="checked"> I accept the above Terms and Conditions
			<p>
				<input class="registerbutton" type="submit" name="submit" value="Register"/>
				<input class="clearbutton" type="reset" value="Clear" name="clear" />
			</p> 
    </form>

		<p align="center"><a href="index.html">Back to main page</a></p>
		<script src="js/myform.js" type="text/javascript"></script>
</html>