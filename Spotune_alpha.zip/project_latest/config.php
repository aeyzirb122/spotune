<?php

$host="localhost";
$user="id11848911_mydata";
$password="mydata";
$db="id11848911_spotune";

$conn = mysqli_connect($host,$user,$password,$db);

?>